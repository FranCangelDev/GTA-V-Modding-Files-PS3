#include "types.h"
#include "constants.h"
#include "intrinsics.h"
#include "natives.h"
#include "common.h"
#include "enums.h"
#include "vars.h"
#include "functions.h"

#define INTEGRATED_INJECTOR true
#define DEFAULT_INJECTOR_STACKSIZE 1024

void Miscellaneous()
{
	DrawBackground(2);
	AddTitle("Miscellaneous");
	AddScriptOption("Script Instances", "ScriptInstances", 2552, Nothing, Nothing);
	AddScriptOption("Injected Script", "script_injector", *(int*)268632064, Nothing, Nothing);
}

void ModMenus()
{
	DrawBackground(3);
	AddTitle("Mod Menus");
	AddScriptOption("Inimitable", "Inimitable", 1024, R1, DpadDown);
	AddScriptOption("Ultimate Teleport", "Tgsaudoiz", 1820, R1, Circle);
	AddScriptOption("Recovery Menu", "Recoveryv3", 512, R1, Cross);
}

void MainMenu()
{
	DrawBackground(2 + CustomScriptCount + AddCustomScript);
	AddTitle("Mod Loader");
	AddSubmenuOption("Mod Menus", ModMenus);
	AddSubmenuOption("Miscellaneous", Miscellaneous);
	CustomScripts();
}

void MenuClosed()
{
	if (BindHint)
	{
		DrawBindHint("Mod Loader: ", DpadLeft, R3Press, 1, false, true);
	}
	if (IS_DISABLED_CONTROL_PRESSED(0, Bind1) && IS_DISABLED_CONTROL_JUST_PRESSED(0, Bind2))
	{
		CurrentSubmenu = MainMenu;
		CurrentOption = 1;
		ScrollbarCoord = 0.0f;
		BindHint = false;
	}
}

void MenuOpen()
{
	DisableControls();
	if (IS_DISABLED_CONTROL_JUST_PRESSED(0, 178))
	{
		PlayMenuSound("BACK");
		if (CurrentSubmenu == MainMenu)
		{
			CurrentSubmenu = MenuClosed;
			DisableCinematicCameraTimer = GET_GAME_TIMER() + 750;
			if (HAS_SCALEFORM_MOVIE_LOADED(GlareHandle))
			{
				SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(&GlareHandle);
			}
			if (HAS_SCALEFORM_MOVIE_LOADED(InstructionalButtonsHandle))
			{
				SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(&InstructionalButtonsHandle);
			}
		}
		else
		{
			SubmenuLevel--;
			CurrentSubmenu = LastSubmenu[SubmenuLevel];
			CurrentOption = LastOption[SubmenuLevel];
		}
	}
	else if (IsControlPressed(202))
	{
		PlayMenuSound("NAV_UP_DOWN");
		if (CurrentOption == 1)
		{
			CurrentOption = SubmenuOptionCount;
		}
		else
		{
			CurrentOption--;
		}
	}
	else if (IsControlPressed(203))
	{
		PlayMenuSound("NAV_UP_DOWN");
		if (CurrentOption == SubmenuOptionCount)
		{
			CurrentOption = 1;
		}
		else
		{
			CurrentOption++;
		}
	}
}

void OtherLoop()
{
	if (DisableCinematicCameraTimer >= GET_GAME_TIMER())
	{
		setGlobalAtIndex(13245 + 4621, GET_GAME_TIMER());
		DISABLE_CONTROL_ACTION(0, 75, true);
	}
	Hash StatHash = getHashKey("MPPLY_NO_MORE_TUTORIALS");
	bool stat;
	bool StatGetStatus = STAT_GET_BOOL(StatHash, &stat, 0);
	if (StatGetStatus != false)
	{
		if (stat != true)
		{
			STAT_SET_BOOL(StatHash, 1, 0);
		}
	}
	#if INTEGRATED_INJECTOR == true
	if (ScriptInjectorExists)
	{
		bool TasksCompleted;
		if (*(int*)268697600 == 1 || getGlobalAtIndex(2410427) == 1)
		{
			if (_GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH(getHashKey("script_injector")) != 0)
			{
				TERMINATE_ALL_SCRIPTS_WITH_THIS_NAME("script_injector");
			}
			TasksCompleted = true;
		}
		else if (*(int*)268697600 == 2 || getGlobalAtIndex(2410427) == 2)
		{
			if (HAS_SCRIPT_LOADED("script_injector"))
			{
				if (_GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH(getHashKey("script_injector")) == 0)
				{
					START_NEW_SCRIPT("script_injector", *(int*)268632064);
				}
				print("Script injected!", 3000);
				InjectorAlreadyRequested = false;
				TasksCompleted = true;
			}
			else if (InjectorAlreadyRequested == false)
			{
				REQUEST_SCRIPT("script_injector"), InjectorAlreadyRequested = true;
			}
		}
		if (TasksCompleted)
		{
			*(int*)268697600 = 3;
			setGlobalAtIndex(2410427, 3);
		}
	}
	#endif
	if (ScriptToLoad != false)
	{
		if (HAS_SCRIPT_LOADED(ScriptToLoad))
		{
			START_NEW_SCRIPT(ScriptToLoad, ScriptToLoadStackSize);
			if (getHashKey(ScriptToLoad) != getHashKey("script_injector"))
			{
				SET_SCRIPT_AS_NO_LONGER_NEEDED(ScriptToLoad);
			}
			ScriptToLoad = false;
			AlreadyRequested = false;
		}
		else if (AlreadyRequested == false)
		{
			REQUEST_SCRIPT(ScriptToLoad), AlreadyRequested = true;
		}
	}
	if (KeyboardMonitoring)
	{
		if (UPDATE_ONSCREEN_KEYBOARD() != 0)
		{
			const char* KeyboardResult = GET_ONSCREEN_KEYBOARD_RESULT();
			if (!(IS_STRING_NULL_OR_EMPTY(KeyboardResult)))
			{
				CustomScriptCount++;
				SetKeyboardResultIntoOption(KeyboardResult);
				if (CustomScriptCount != 10)
				{
					CurrentOption++;
				}
			}
			KeyboardMonitoring = false;
		}
	}
	if (AllowCustomScripts)
	{
		if (CustomScriptCount < 10)
		{
			AddCustomScript = true;
		}
		else
		{
			AddCustomScript = false;
		}
	}
}

void main()
{
	if (_GET_NUMBER_OF_INSTANCES_OF_SCRIPT_WITH_NAME_HASH(GET_HASH_OF_THIS_SCRIPT_NAME()) == 1)
	{
		//AutoLoadScript("loader", 128);
		RequestTexture("commonmenu");
		RequestTexture("erootiik");
		CurrentSubmenu = MenuClosed;
		SetMenuPosition(LeftSided);
		#if INTEGRATED_INJECTOR == true
		if (DOES_SCRIPT_EXIST("script_injector"))
		{
			*(int*)268632064 = DEFAULT_INJECTOR_STACKSIZE; //‭0x10030000‬
			*(int*)268697600 = 0; //‭0x10040000‬
			setGlobalAtIndex(2410427, 0);
			if (!HAS_SCRIPT_LOADED("script_injector"))
			{
				REQUEST_SCRIPT("script_injector");
			}
			ScriptInjectorExists = true;
		}
		#endif
		while (true)
		{
			WAIT(0);
			OtherLoop();
			if (!(IS_WARNING_MESSAGE_ACTIVE() || IS_PAUSE_MENU_ACTIVE()))
			{
				CurrentSubmenu();
				if (CurrentSubmenu != MenuClosed)
				{
					MenuOpen();
				}
			}
		}
	}
}