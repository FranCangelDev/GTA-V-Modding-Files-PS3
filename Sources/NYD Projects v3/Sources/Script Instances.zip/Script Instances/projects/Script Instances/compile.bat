@echo off
cd %~dp0
:start
echo SC-CL ScriptInstances.c
echo Press ENTER to launch
pause > nul
cls
"../../bin/SC-CL.exe" -O3 -emit-asm -platform=PS3 -target=GTAV -out-dir="GTAV/PS3/bin/" ScriptInstances.c ../../include/common.c -- -I "../../include/"
goto start
